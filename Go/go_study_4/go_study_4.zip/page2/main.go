package main

import "fmt"

func main() {
	name := "Yahya"

	// Cetak variable alamat memori `name`
	fmt.Println(&name)

}
