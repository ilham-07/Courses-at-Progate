package main

import "fmt"

func main() {
	// Potong dan tempelkan code di bawah ini
	// Potong dan tempelkan code di bawah ini
	
	// Panggil function ask
	ask()
	
}

// Definisikan function ask
func ask() {
    var input string
	fmt.Println("Silahkan memasukkan kata berikut: kucing")
	fmt.Scan(&input)
	fmt.Printf("%s telah dimasukkan", input)
}
