package main

func main() {
    // Cetak hasil dari 12 dibagi dengan 3
    println(12/3)
    
    // Cetak hasil dari 3 dikali 6
    println(3*6)
    
    // Cetak sisa hasil pembagian dari 8 dibagi dengan 3
    println(8%3)
    
}
