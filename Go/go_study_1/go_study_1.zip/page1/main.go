package main

func main() {
    // Ubah "world" menjadi "Go" dibawah ini
    println("Hello, Go")
}
