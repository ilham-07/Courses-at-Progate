# Definisikan method `print_info`
def print_info(item)
  puts "Selamat datang di Toko Elektronik Ninja!"
  puts "#{item} sedang diskon hari ini!"
end

# Panggil method `print_info` dengan argument "Headphone"
print_info("Headphone")

# Panggil method `print_info` dengan argument "TV"
print_info("TV")
