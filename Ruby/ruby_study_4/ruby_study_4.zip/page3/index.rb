class Menu
  # Tambahkan variable instance `name` dan `price`
  attr_accessor :name
  attr_accessor :price
end
