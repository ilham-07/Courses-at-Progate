score = 60

# Tambahkan sebuah pernyataan `else` untuk mencetak "Anda bisa lebih baik lagi!"
if score > 80
  puts "Bagus sekali!"
else
  puts "Anda bisa lebih baik lagi!"
end
