score = 92

# Jika nilai score lebih besar daripada 80, cetak "Bagus sekali!"
if score > 80
  puts "Bagus sekali!"
end