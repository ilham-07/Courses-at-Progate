require "./menu"

class Food < Menu
end
