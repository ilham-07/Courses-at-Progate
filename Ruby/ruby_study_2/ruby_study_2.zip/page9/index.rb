exam = {subject: "Matematika", score: 80}

# Cetak nilai dari simbol :grade
puts exam[:grade]

# Cetak nil
puts nil
