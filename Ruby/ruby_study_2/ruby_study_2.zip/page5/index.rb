# Tetapkan sebuah hash kedalam variable `exam`
exam = {"subject" => "Matematika" , "score" => 80}

# Cetak variable `exam`
puts exam
