# Cetak 7 sebagai sebuah integer
print(7)

# Cetak penjumlahan dari 9 dan 3
print(9+3)

# Cetak '9 + 3' sebagai string
print('9+3')