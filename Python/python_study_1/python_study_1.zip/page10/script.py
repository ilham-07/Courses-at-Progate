x = 7 * 10
y = 5 * 6

# Jika x sama dengan 70, cetak 'x adalah 70'
if x == 70:
  print("x adalah 70")

# Jika y tidak sama dengan 40, cetak 'y bukan 40' 
if y != 40:
  print("y bukan 40")