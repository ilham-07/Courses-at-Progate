fruits = ['apel', 'pisang', 'jeruk']

# Dapatkan element fruits menggunakan loop for, dan cetak 'Saya suka ___'
for fruit in fruits:
    print('Saya suka' + fruit)