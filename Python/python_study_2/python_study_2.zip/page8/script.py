x = 10

# Buat loop while yang diulang selama x lebih besar dari 0
while x > 0:
    # Cetak variable x  
    print(x)
    # Kurangi 1 dari variable x 
    x -= 1