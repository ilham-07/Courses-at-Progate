-- dapatkan jumlah baris di tabel purchases 
SELECT COUNT(*)
FROM purchases;