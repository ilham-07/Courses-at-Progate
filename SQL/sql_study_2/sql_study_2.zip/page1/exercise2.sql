-- dapatkan baris dari kolom character_name dengan duplikat dihilangkan
SELECT DISTINCT (character_name)
FROM purchases;