-- dapatkan total jumlah dari kolom price
SELECT SUM(price)
FROM purchases;