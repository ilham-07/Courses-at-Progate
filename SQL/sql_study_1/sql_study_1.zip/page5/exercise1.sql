/*
dibawah baris "FROM purchases" tambahkan code untuk
mendapatkan baris dengan nilai "10" dikolom "price" 
*/

SELECT *
FROM purchases
WHERE price = 10;