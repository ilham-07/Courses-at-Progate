-- dapatkan nilai rata-rata umur semua pengguna
SELECT AVG(age)
FROM users;
