INSERT INTO items(id,name) VALUES (1,'kentang');
INSERT INTO items(id,name) VALUES (2,'wortel');
INSERT INTO items(id,name) VALUES (3,'bawang');