class Car extends Vehicle {
}
