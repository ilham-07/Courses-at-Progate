class Main {
  public static void main(String[] args) {
    // Cetak 17 sebagai integer
    System.out.println(17);
    
    // Cetak jumlah dari 5 dan 3
    System.out.println(5 + 3);
    
    // Cetak "5 + 3" sebagai string
    System.out.println("5 + 3");
    
  }
}
