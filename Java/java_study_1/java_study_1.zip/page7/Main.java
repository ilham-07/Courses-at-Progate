class Main {
  public static void main(String[] args) {
    int number1 = 3;
    
    // Deklarasikan variable number2 dari tipe int, dan tetapkan 7 padanya.
    int number2 = 7;
    
    // Cetak hasil dari number1 * number2
    System.out.println(number1 * number2);
    
    // Tetapkan "Ayo belajar pemrograman" ke variable text
    String text = "Ayo belajar pemrograman";
    
    // Gabungkan variable text dan string yang diberikan, dan cetak hasilnya 
    System.out.println(text + " menggunakan Progate");
    
  }
}
