class Main {
  public static void main(String[] args) {
    int number = 11;
    String text = "Ruby";
    System.out.println(number);
    System.out.println(text);
    
    // Perbarui variable number dengan 9
    number = 9;
    
    // Cetak variable number
    System.out.println(number);
    
    // Perbarui variable text dengan "Java"
    text = "Java";
    
    // Cetak variable text
    System.out.println(text);
    
  }
}
