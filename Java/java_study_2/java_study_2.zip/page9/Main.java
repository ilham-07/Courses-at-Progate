class Main {
  public static void main(String[] args) {
    // Buat loop for yang berjalan 10 kali
    for (int i = 1; i <= 10; i++) {
      System.out.println("Hitungan loop:" + i);
    }
    
  }
}