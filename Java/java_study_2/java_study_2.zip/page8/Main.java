class Main {
  public static void main(String[] args) {
    int number = 10;
    
    // Buat loop while yang diulang ketika number lebih besar dari 0
    while (number > 0) {
      System.out.println(number);
      number--;
    }
    
  }
}