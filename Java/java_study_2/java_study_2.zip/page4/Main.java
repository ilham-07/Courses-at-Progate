class Main {
  public static void main(String[] args) {
    // Berikan true sebagai kondisi untuk statement if
    if (true) {
      System.out.println("Kondisi adalah true. Cetak...");
    }
    
    // Berikan false sebagai kondisi untuk statement if
    if (false) {
      System.out.println("Kondisi adalah false. Tidak mencetak...");
    }
    
    int x = 5;
    // Jika x lebih besar dari 2, cetak "x lebih besar dari 2"
    if (x > 2) {
      System.out.println("x lebih besar dari 2");
    }
    
    // Jika x lebih besar dari 8, cetak "x lebih besar dari 8"
    if (x > 8) {
      System.out.println("x lebih besar dari 8");
    }
    
  }
}