class Main {
  public static void main(String[] args) {
    // Panggil method printData
    printData();
    
  }
  
  // Deklarasikan method printData
  public static void printData() {
    System.out.println("Nama saya adalah Kate Jones.");
  }
  
}
