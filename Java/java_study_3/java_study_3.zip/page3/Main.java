class Main {
  public static void main(String[] args) {
    // Teruskan argument "Kate Jones"
    printData("Kate Jones");
    
    // Teruskan argument "John Christopher Smith"
    printData("John Christopher Smith");
    
  }

  // Edit method agar dapat menerima argument
  public static void printData(String name) {
    // Hasil "Nama saya adalah ____."
    System.out.println("Nama saya adalah" + name +".");
    
  }
}
