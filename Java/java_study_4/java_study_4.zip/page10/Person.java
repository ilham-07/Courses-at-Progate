class Person {
  // Deklarasikan field-field instance
  public String firstName;
  public String lastName;
  public int age;
  public double height;
  public double weight;
  
  // Definisikan constructor untuk mengatur field-field instance
  Person(String firstName, String lastName, int age, double height, double weight) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
    this.height = height;
    this.weight = weight;
  }
  
}
