import React from 'react';

class App extends React.Component {
  render() {
    return (
      <div>
        {/* tambahkan class ke tag h1 */}
        <h1 className = "title">Hello World</h1>
        <p>Ayo belajar React bersama!</p>
      </div>
    );
  }
}

export default App;
