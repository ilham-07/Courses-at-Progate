// Deklarasikan constant language
const language = "Prancis";

// Cetak nilai constant language
console.log(language);

// Gunakan constant language untuk mencetak "Saya bisa berbicara bahasa ____"
console.log("Saya bisa berbicara bahasa" + language);
