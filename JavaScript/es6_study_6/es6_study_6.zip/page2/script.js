const characters = ["Ninja Ken", "Baby Ben", "Guru Domba", "Birdie"];

// Cetak semua element didalam array characters dengan menggunakan method forEach
characters.forEach((character) => {
  console.log(character)
});