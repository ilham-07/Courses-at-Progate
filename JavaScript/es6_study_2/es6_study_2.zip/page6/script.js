const animals = ["anjing", "kucing", "domba"];

// Print element array pertama
console.log(animals[0]);

// Print element array ketiga
console.log(animals[2]);