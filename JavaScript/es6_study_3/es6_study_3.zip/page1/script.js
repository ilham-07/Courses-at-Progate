const greet = function() {
  console.log("Halo!");
  console.log("Ayo belajar function!");
};

// Panggil function greet dibawah
greet();