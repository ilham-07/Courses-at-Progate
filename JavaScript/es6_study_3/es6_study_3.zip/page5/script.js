// Tambahkan parameter number1 dan number2 kedalam function 
const add = (number1, number2) => {
  // Print penjumlahaan number1 dan number2
  console.log(number1 + number2);
};

// Panggil function dengan 5 dan 7 sebagai argument
add(5,7);
